#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "QtInc.h"

QT_BEGIN_NAMESPACE

class Pane;
class PreviewPane;
class PathValidator;

class MainWindow : public QMainWindow {
Q_OBJECT

public:
    MainWindow(QWidget* parent = 0);
    ~MainWindow();
    QFileSystemModel* fileSystemModel;
    QTreeView *directoryTreeView;
    QSortFilterProxyModel *fileSystemProxyModel;
    QMenu *contextMenu;

    void setActivePane(Pane* pane);
    Pane* getActivePane();
    void moveTo(QString path);
    void updateViewActions();

public slots:
    void clipboardChanged();

protected:
    void closeEvent(QCloseEvent *event);
    bool eventFilter(QObject *obj, QEvent *event);

signals:

private:
    QMenuBar *menuBar;
    //QToolBar *toolBar;

    QMenu* fileMenu;
    QMenu* editMenu;
    QMenu* viewMenu;
    QMenu* helpMenu;
    QMenu* SNSMenu;
    QMenu* appssubMenu;
    QMenu* createsubMenu;
    QIcon* aboutIcon;
    QAction* exitAction;
    QAction* cutAction;
    QAction* copyAction;
    QAction* pasteAction;
    QAction* deleteAction;
    QAction* newFolderAction;
    QAction* detailViewAction;
    QAction* iconViewAction;
    QAction* hiddenAction;
    QActionGroup* viewActionGroup;
    QAction* aboutAction;
    QAction* aboutQtAction;
    QAction* settingsAction;
    QAction* startcmdAction;
    QAction* startdiskusageAction;
    QAction* starttextsearchAction;
    Pane* leftPane;
    Pane* rightPane;
    Pane* activePane;
    QSplitter* splitter;
    QItemSelectionModel* treeSelectionModel;
    QLabel *SNSLogo;

    void createActionsAndMenus();
    void writeSettings();
    void readSettings();
    void activeView();

private slots:
    void treeSelectionChanged(QModelIndex current, QModelIndex previous);
    void cut();
    void copy();
    void paste();
    void del();
    void newFolder();
    void showAboutBox();
    void focusChangedSlot(QWidget *, QWidget *now);
    void toggleToDetailView();
    void toggleToIconView();
    void toggleHidden();
    void toggleSettings();
    void toggleStartCMD();
    void toggleStartDiskUsage();
    void toggleStartTextSearch();
    void showContextMenu(const QPoint&);
};

class FileSystemModelFilterProxyModel : public QSortFilterProxyModel
{
protected:
    virtual bool filterAcceptsRow(int sourceRow, const QModelIndex& sourceParent) const;
};

QT_END_NAMESPACE

#endif // MAINWINDOW_H
