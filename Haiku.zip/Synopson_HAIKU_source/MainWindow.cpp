#include "MainWindow.h"
#include "Pane.h"
#include "SetupDialog.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    setWindowTitle(tr("Synopson"));
    createActionsAndMenus();
    splitter = new QSplitter(this);

    fileSystemModel = new QFileSystemModel;
    fileSystemModel->setFilter(QDir::NoDot | QDir::AllEntries | QDir::System);
    fileSystemModel->setRootPath("");
    fileSystemModel->setReadOnly(false);

    fileSystemProxyModel = new FileSystemModelFilterProxyModel();
    fileSystemProxyModel->setSourceModel(fileSystemModel);
    fileSystemProxyModel->setSortCaseSensitivity(Qt::CaseInsensitive);
    //fileSystemProxyModel->sort(0);

    directoryTreeView = new QTreeView(splitter);
    directoryTreeView->setStyleSheet("background: #fffff0;");  // слоновая кость -- цвет фона дерева файловой системы
    directoryTreeView->setModel(fileSystemProxyModel);
    directoryTreeView->setHeaderHidden(true);
    directoryTreeView->setUniformRowHeights(true);
    directoryTreeView->hideColumn(1);
    directoryTreeView->hideColumn(2);
    directoryTreeView->hideColumn(3);
    directoryTreeView->setDragDropMode(QAbstractItemView::DropOnly);
    directoryTreeView->setDefaultDropAction(Qt::MoveAction);
    directoryTreeView->setDropIndicatorShown(true);
    directoryTreeView->setEditTriggers(QAbstractItemView::EditKeyPressed | QAbstractItemView::SelectedClicked);
    directoryTreeView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(directoryTreeView, SIGNAL(customContextMenuRequested(const QPoint&)), this, SLOT(showContextMenu(const QPoint&)));
    treeSelectionModel = directoryTreeView->selectionModel();
    connect(treeSelectionModel, SIGNAL(currentChanged(QModelIndex, QModelIndex)), this, SLOT(treeSelectionChanged(QModelIndex, QModelIndex)));

    leftPane = new Pane(splitter);
    rightPane = new Pane(splitter);

    connect(qApp, SIGNAL(focusChanged(QWidget*, QWidget*)), SLOT(focusChangedSlot(QWidget*, QWidget*)));

    splitter->addWidget(directoryTreeView);
    splitter->addWidget(leftPane);
    splitter->addWidget(rightPane);
    splitter->setHandleWidth(1);
    this->setCentralWidget(splitter);
    connect(QApplication::clipboard(), SIGNAL(changed(QClipboard::Mode)), this, SLOT(clipboardChanged()));
    readSettings();
    SNSLogo = new QLabel(this);
    SNSLogo->setPixmap(QPixmap(":/Images/SNSlogo_16.png"));
    SNSLogo->installEventFilter(this);
    statusBar()->addPermanentWidget(SNSLogo);
}

MainWindow::~MainWindow()
{

}

bool MainWindow::eventFilter(QObject *obj, QEvent *event)
{
	if(event->type() == QEvent::Enter)
	{
		SNSLogo->setPixmap(QPixmap(":/Images/SNSogol_16.png"));
		return QObject::eventFilter(obj, event);
	}
	
	if(event->type() == QEvent::Leave)
	{
		SNSLogo->setPixmap(QPixmap(":/Images/SNSlogo_16.png"));
		return QObject::eventFilter(obj, event);
	}
	
	if(event->type() == QEvent::MouseButtonPress)
	{
		showAboutBox();
		return true;
	}
	else {
		// standard event processing
		return QObject::eventFilter(obj, event);
	}
}
		
void MainWindow::focusChangedSlot(QWidget *, QWidget *now)
{
    if (now == rightPane->pathLineEdit || now == rightPane->treeView || now == rightPane->listView)
        setActivePane(rightPane);
    else if (now == leftPane->pathLineEdit || now == leftPane->treeView || now == leftPane->listView)
        setActivePane(leftPane);
}

void MainWindow::setActivePane(Pane* pane)
{
    pane->setActive(true);
    if (pane == leftPane) {
        leftPane->stackedWidget->setStyleSheet("border: 1px solid #5555ff;");
        rightPane->setActive(false);
        rightPane->stackedWidget->setStyleSheet("border: default;");
    }
    else {
        rightPane->stackedWidget->setStyleSheet("border: 1px solid #ff5555;");
        leftPane->setActive(false);
        leftPane->stackedWidget->setStyleSheet("border: default;");
    }
    activePane = pane;
    updateViewActions();
}

Pane* MainWindow::getActivePane()
{
    return(activePane);
}

void MainWindow::treeSelectionChanged(QModelIndex current, QModelIndex previous)
{
    QFileInfo fileInfo(fileSystemModel->fileInfo(fileSystemProxyModel->mapToSource(current)));
    if(!fileInfo.exists())
        return;
    getActivePane()->moveTo(fileInfo.filePath());
}

void MainWindow::moveTo(const QString path)
{
    QModelIndex index = fileSystemProxyModel->mapFromSource(fileSystemModel->index(path));
    treeSelectionModel->select(index, QItemSelectionModel::Select);
    getActivePane()->moveTo(path);
}

void MainWindow::showContextMenu(const QPoint& position)
{
    contextMenu->exec(directoryTreeView->mapToGlobal(position));
}

void MainWindow::cut()
{
    QModelIndexList selectionList;

    QWidget* focus(focusWidget());
    QAbstractItemView* view;
    if (focus == directoryTreeView || focus == leftPane->treeView || focus == leftPane->listView || focus == rightPane->treeView || focus == rightPane->listView){
        view =  qobject_cast<QAbstractItemView *>(focus);
        selectionList = view->selectionModel()->selectedIndexes();
    }

    if(selectionList.count() == 0)
        return;

    QApplication::clipboard()->setMimeData(fileSystemModel->mimeData(selectionList));
    pasteAction->setData(true);

    view->selectionModel()->clear();

}

void MainWindow::copy()
{
    QModelIndexList selectionList;

    QWidget* focus(focusWidget());
    QAbstractItemView* view;
    if (focus == directoryTreeView || focus == leftPane->treeView || focus == leftPane->listView || focus == rightPane->treeView || focus == rightPane->listView){
        view =  qobject_cast<QAbstractItemView *>(focus);
        selectionList = view->selectionModel()->selectedIndexes();
    }

    if(selectionList.count() == 0)
        return;

    QApplication::clipboard()->setMimeData(fileSystemModel->mimeData(selectionList));
    pasteAction->setData(false);
	pasteAction->setEnabled(true);
}

void MainWindow::paste()
{
    QWidget* focus(focusWidget());
    Qt::DropAction cutOrCopy(pasteAction->data().toBool() ? Qt::MoveAction : Qt::CopyAction);

    if (focus == leftPane->treeView || focus == leftPane->listView || focus == rightPane->treeView || focus == rightPane->listView){
        fileSystemModel->dropMimeData(QApplication::clipboard()->mimeData(), cutOrCopy, 0, 0, qobject_cast<QAbstractItemView *>(focus)->rootIndex());
    } else if (focus == directoryTreeView){
        fileSystemModel->dropMimeData(QApplication::clipboard()->mimeData(), cutOrCopy, 0, 0,  fileSystemProxyModel->mapToSource(directoryTreeView->currentIndex()));
    }
}

void MainWindow::del()
{
    QModelIndexList selectionList;
    bool yesToAll = false;
    bool ok = false;
    bool confirm = true;

    QWidget* focus(focusWidget());
    QAbstractItemView* view;
    if (focus == directoryTreeView || focus == leftPane->treeView || focus == leftPane->listView || focus == rightPane->treeView || focus == rightPane->listView){
        view = qobject_cast<QAbstractItemView *>(focus);
        selectionList = view->selectionModel()->selectedIndexes();
    }

    for(int i = 0; i < selectionList.count(); ++i)
    {
        QFileInfo file(fileSystemModel->filePath(selectionList.at(i)));
        if(file.isWritable())
        {
            if(file.isSymLink()) ok = QFile::remove(file.filePath());
            else
            {
                if(!yesToAll)
                {
                    if(confirm)
                    {
                        int answer = QMessageBox::information(this, tr("Delete this"), tr("Are you sure you want to delete")+"<p><b>\"" + file.filePath() + "</b> ?",QMessageBox::Yes | QMessageBox::No | QMessageBox::YesToAll);
                        if(answer == QMessageBox::YesToAll)
                            yesToAll = true;
                        if(answer == QMessageBox::No)
                            return;
                    }
                }
                ok = fileSystemModel->remove(selectionList.at(i));
            }
        }
        else if(file.isSymLink())
            ok = QFile::remove(file.filePath());
    }

    if(!ok)
        QMessageBox::information(this, tr("Delete Failed"), tr("Some files could not be deleted."));
}

void MainWindow::newFolder()
{
    QAbstractItemView* currentView = qobject_cast<QAbstractItemView *>(getActivePane()->stackedWidget->currentWidget());
    QModelIndex newDir = fileSystemModel->mkdir(currentView->rootIndex(), QString(tr("New folder")));

    if (newDir.isValid()) {
        currentView->selectionModel()->setCurrentIndex(newDir, QItemSelectionModel::ClearAndSelect);
        currentView->edit(newDir);
    }
}

void MainWindow::clipboardChanged()
{
    if(QApplication::clipboard()->mimeData()->hasUrls())
        pasteAction->setEnabled(true);
    else
        pasteAction->setEnabled(false);
}

void MainWindow::toggleToDetailView()
{
    getActivePane()->setViewTo(Pane::TreeViewMode);
}

void MainWindow::toggleToIconView()
{
    getActivePane()->setViewTo(Pane::ListViewMode);
}

void MainWindow::toggleHidden()
{
    if(hiddenAction->isChecked())
        fileSystemModel->setFilter(QDir::NoDot | QDir::AllEntries | QDir::System | QDir::Hidden);
    else
        fileSystemModel->setFilter(QDir::NoDot | QDir::AllEntries | QDir::System);
}

void MainWindow::toggleSettings()
{
    SetupDialog dialog;
    dialog.exec();
}

void MainWindow::toggleStartCMD()
{
    QProcess::startDetached("Terminal");
//    QMessageBox::information(this, tr("Few minutes please."), tr("Coming soon...") +" <b>"+ activePane->pathLineEdit->text());
}

void MainWindow::toggleStartDiskUsage()
{
    QProcess::startDetached("DiskUsage");
}

void MainWindow::toggleStartTextSearch()
{
    QProcess::startDetached("TextSearch");
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    writeSettings();
    event->accept();
}

void MainWindow::createActionsAndMenus()
// Construct actions, menus and toolbars
{    
    deleteAction = new QAction(QIcon::fromTheme("edit-delete"), tr("Delete"), this );
    deleteAction->setStatusTip(tr("Delete file"));
    deleteAction->setShortcut(QKeySequence::Delete);
    connect(deleteAction, SIGNAL(triggered()), this, SLOT(del()));

    newFolderAction = new QAction(QIcon::fromTheme("edit-delet"), tr("New Folder"), this );
    newFolderAction->setStatusTip(tr("Create New Folder"));
    newFolderAction->setShortcut(QKeySequence::New);
    connect(newFolderAction, SIGNAL(triggered()), this, SLOT(newFolder()));

    exitAction = new QAction(QIcon::fromTheme("application-exit"), tr("&Exit"), this );
    exitAction->setMenuRole(QAction::QuitRole);
    exitAction->setStatusTip(tr("Quit Synopson"));
    exitAction->setShortcut(QKeySequence::Quit);
    connect(exitAction, SIGNAL(triggered()), this, SLOT(close()));

    cutAction = new QAction(QIcon::fromTheme("edit-cut"), tr("Cut"), this );
    cutAction->setStatusTip(tr("Cut file"));
    cutAction->setShortcut(QKeySequence::Cut);
    connect(cutAction, SIGNAL(triggered()), this, SLOT(cut()));

    copyAction = new QAction(QIcon::fromTheme("edit-copy"), tr("Copy"), this );
    copyAction->setStatusTip(tr("Copy file"));
    copyAction->setShortcut(QKeySequence::Copy);
    connect(copyAction, SIGNAL(triggered()), this, SLOT(copy()));

    pasteAction = new QAction(QIcon::fromTheme("edit-paste"), tr("Paste"), this );
    pasteAction->setStatusTip(tr("Paste file"));
    pasteAction->setEnabled(false);
    pasteAction->setShortcut(QKeySequence::Paste);
    connect(pasteAction, SIGNAL(triggered()), this, SLOT(paste()));

    detailViewAction = new QAction(QIcon::fromTheme("view-list-details"), tr("Detail View"), this );
    detailViewAction->setStatusTip(tr("Show list in detail"));
    detailViewAction->setCheckable(true);
    connect(detailViewAction, SIGNAL(triggered()), this, SLOT(toggleToDetailView()));

    iconViewAction = new QAction(QIcon::fromTheme("view-list-icons"), tr("Icon View"), this );
    iconViewAction->setStatusTip(tr("Show list as icons"));
    iconViewAction->setCheckable(true);
    connect(iconViewAction, SIGNAL(triggered()), this, SLOT(toggleToIconView()));

    hiddenAction = new QAction(QIcon::fromTheme("folder-saved-search"), tr("Show Hidden"), this );
    hiddenAction->setStatusTip(tr("Show hidden items"));
    hiddenAction->setCheckable(true);
    connect(hiddenAction, SIGNAL(triggered()), this, SLOT(toggleHidden()));

    viewActionGroup = new QActionGroup(this);
    viewActionGroup->addAction(detailViewAction);
    viewActionGroup->addAction(iconViewAction);

    aboutAction = new QAction(QIcon(":/Images/SNSlogo.png"), tr("&About"), this );
    aboutAction->setStatusTip(tr("About Synopson"));
    aboutAction->setMenuRole (QAction::AboutRole);
    connect(aboutAction, SIGNAL(triggered()), this, SLOT(showAboutBox()));

    aboutQtAction = new QAction(QIcon(":/Images/qt_logo.png"),tr("About &Qt"), this);
    aboutQtAction->setStatusTip(tr("Show the Qt library's About box"));
    connect(aboutQtAction, SIGNAL(triggered()), qApp, SLOT(aboutQt()));

    settingsAction = new QAction(QIcon(":/Images/SNSset.png"), tr("&Program settings..."), this );
    settingsAction->setStatusTip(tr("Changes program settings"));
    connect(settingsAction, SIGNAL(triggered()), this, SLOT(toggleSettings()));

    startcmdAction = new QAction(tr("&Start Terminal"), this);
//    appsAction->setStatusTip(tr("Some additional opportunities, in relation to it...")); // Некоторые дополнительные возможности, приминительно к этому...
    connect(startcmdAction, SIGNAL(triggered()), this, SLOT(toggleStartCMD()));

	startdiskusageAction = new QAction(tr("&DiskUsage"), this);
	connect(startdiskusageAction, SIGNAL(triggered()), this, SLOT(toggleStartDiskUsage()));

	starttextsearchAction = new QAction(tr("&TextSearch"), this);
	connect(starttextsearchAction, SIGNAL(triggered()), this, SLOT(toggleStartTextSearch()));

    menuBar = new QMenuBar(0);

    fileMenu = menuBar->addMenu(tr("&File"));
    fileMenu->addAction(newFolderAction);
    fileMenu->addAction(deleteAction);
    fileMenu->addSeparator();
    fileMenu->addAction(exitAction);

    editMenu = menuBar->addMenu(tr("&Edit"));
    editMenu->addAction(cutAction);
    editMenu->addAction(copyAction);
    editMenu->addAction(pasteAction);

    viewMenu = menuBar->addMenu(tr("&View"));
    viewMenu->addAction(detailViewAction);
    viewMenu->addAction(iconViewAction);
    viewMenu->addAction(hiddenAction);

    SNSMenu = menuBar->addMenu(tr("&Synopson"));
    SNSMenu->addAction(settingsAction);
    SNSMenu->addSeparator();
    SNSMenu->addAction(aboutAction);

    helpMenu = menuBar->addMenu(tr("&Help"));
    helpMenu->addAction(aboutQtAction);

    setMenuBar(menuBar);

    //toolBar = addToolBar(tr("Main"));

    contextMenu = new QMenu(this);
    contextMenu->addAction(detailViewAction);
    contextMenu->addAction(iconViewAction);
    contextMenu->addSeparator();
    createsubMenu = contextMenu->addMenu(tr("&Create..."));
    createsubMenu->addAction(newFolderAction);
    contextMenu->addSeparator();
    contextMenu->addAction(cutAction);
    contextMenu->addAction(copyAction);
    contextMenu->addAction(pasteAction);
    contextMenu->addSeparator();
    contextMenu->addAction(deleteAction);
    contextMenu->addSeparator();
    appssubMenu = contextMenu->addMenu(tr("&Additions..."));
    appssubMenu->addAction(startdiskusageAction);
    appssubMenu->addAction(starttextsearchAction);
    appssubMenu->addSeparator();
    appssubMenu->addAction(startcmdAction);
    

}

void MainWindow::writeSettings()
{
    QSettings settings("Free Software", "Synopson");
    settings.setValue("Geometry", saveGeometry());
    settings.setValue("MainSplitterSizes", splitter->saveState());
    settings.setValue("LeftPaneActive", leftPane->isActive());
    settings.setValue("LeftPanePath", leftPane->pathLineEdit->text());
    settings.setValue("LeftPaneFileListHeader", leftPane->treeView->header()->saveState());
    settings.setValue("LeftPaneViewMode", leftPane->stackedWidget->currentIndex());
    settings.setValue("RightPanePath", rightPane->pathLineEdit->text());
    settings.setValue("RightPaneFileListHeader", rightPane->treeView->header()->saveState());
    settings.setValue("RightPaneViewMode", rightPane->stackedWidget->currentIndex());
    settings.setValue("ShowHidden", hiddenAction->isChecked());
}

void MainWindow::readSettings()
{
    QSettings settings("Free Software", "Synopson");
    restoreGeometry(settings.value("Geometry").toByteArray());
    splitter->restoreState(settings.value("MainSplitterSizes").toByteArray());
    setActivePane(settings.value("LeftPaneActive", 1).toBool() ? leftPane : rightPane);
    leftPane->treeView->header()->restoreState(settings.value("LeftPaneFileListHeader").toByteArray());
    leftPane->moveTo(settings.value("LeftPanePath", "").toString());
    leftPane->stackedWidget->setCurrentIndex(settings.value("LeftPaneViewMode", 0).toInt());
    rightPane->treeView->header()->restoreState(settings.value("RightPaneFileListHeader").toByteArray());
    rightPane->moveTo(settings.value("RightPanePath", "").toString());
    rightPane->stackedWidget->setCurrentIndex(settings.value("RightPaneViewMode", 0).toInt());
    hiddenAction->setChecked(settings.value("ShowHidden", false).toBool());
    toggleHidden();
}

void MainWindow::updateViewActions()
{
    switch (activePane->stackedWidget->currentIndex())
    {
    case Pane::TreeViewMode:
        detailViewAction->setChecked(true);
        break;
    case Pane::ListViewMode:
        iconViewAction->setChecked(true);
        break;
    }
}

void MainWindow::showAboutBox()
{
    QMessageBox::about(this, tr("About Synopson"),
                       tr("<h2>Synopson</h2>"
                          "<p><em>Version 0.9.0</em>"
                          "<p>File Manager<br>"
                          "2011 - 2013 by Thomas F&uuml;hringer<br>"
                          "...also it is partially adapted by users.<br>"
                          "<br>"
                          "some Icons made by Gregor Cresnar from is licensed by Creative Commons BY 3.0"));
}


//-----------------------

bool FileSystemModelFilterProxyModel::filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const
{
    QModelIndex index0 = sourceModel()->index(sourceRow, 0, sourceParent);
    QFileSystemModel* fileSystemModel = qobject_cast<QFileSystemModel*>(sourceModel());
    if (fileSystemModel->isDir(index0) && fileSystemModel->fileName(index0).compare("..") != 0)
        return true;
    else
        return false;
}
