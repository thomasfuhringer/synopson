#include "MainWindow.h"
#include "SetupDialog.h"

SetupDialog::SetupDialog() // Windows Dialog
{
    contentsWidget = new QListWidget;
    contentsWidget->setViewMode(QListView::IconMode);
    contentsWidget->setIconSize(QSize(96, 96));
    contentsWidget->setMovement(QListView::Static);
    contentsWidget->setMaximumWidth(220);
    contentsWidget->setSpacing(12);

    pagesWidget = new QStackedWidget;
    pagesWidget->addWidget(new SetLangPage);
    pagesWidget->addWidget(new OtherPage);

    closeButton = new QPushButton(tr("Close"));

    createIcons();
    contentsWidget->setCurrentRow(0);

    connect(closeButton, &QAbstractButton::clicked, this, &QWidget::close);

    horizontalLayout = new QHBoxLayout;
    horizontalLayout->addWidget(contentsWidget);
    horizontalLayout->addWidget(pagesWidget, 1);

    buttonsLayout = new QHBoxLayout;
    buttonsLayout->addStretch(1);
    buttonsLayout->addWidget(closeButton);

    mainLayout = new QVBoxLayout;
    mainLayout->addLayout(horizontalLayout);
    mainLayout->addStretch(1);
    mainLayout->addSpacing(12);
    mainLayout->addLayout(buttonsLayout);
    setLayout(mainLayout);

    setWindowTitle(tr("Program settings..."));
}

void SetupDialog::createIcons()
{
    SetLangButton = new QListWidgetItem(contentsWidget);
    SetLangButton->setIcon(QIcon(":/Images/user.png"));
    SetLangButton->setText(tr("Choice of language"));
    SetLangButton->setTextAlignment(Qt::AlignHCenter);
    SetLangButton->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

    otherButton = new QListWidgetItem(contentsWidget);
    otherButton->setIcon(QIcon(":/Images/set96.png"));
    otherButton->setText(tr("Other"));
    otherButton->setTextAlignment(Qt::AlignHCenter);
    otherButton->setFlags(Qt::ItemIsSelectable | Qt::ItemIsEnabled);

    connect(contentsWidget, &QListWidget::currentItemChanged, this, &SetupDialog::changePage);
}

void SetupDialog::changePage(QListWidgetItem *current, QListWidgetItem *previous)
{
    if (!current)
        current = previous;

    pagesWidget->setCurrentIndex(contentsWidget->row(current));
}


SetLangPage::SetLangPage(QWidget *parent) : QWidget(parent)   // Setup language page
{
    languageGroup = new QGroupBox(tr("To choose language..."));

    languageLabel = new QLabel(tr("Language:"));
    languageCombo = new QComboBox;
    languageCombo->addItem(QIcon(":/Images/UK.png"), tr("English"));
    languageCombo->addItem(QIcon(":/Images/RU.png"), tr("Russian"));
    languageCombo->addItem(QIcon(":/Images/UA.png"), tr("Ukrainian"));
    languageCombo->addItem(QIcon(":/Images/DE.png"), tr("Deutsch"));
    if (QFile::exists("/boot/home/config/settings/Synopson_config")) {
        SNS_lng_set = new QSettings("/boot/home/config/settings/Synopson_config", QSettings::IniFormat);
        languageCombo->setCurrentIndex(SNS_lng_set->value("Language/SNSlocale", 0).toInt());
    }
    connect(languageCombo, SIGNAL(activated(int)), this, SLOT(langChanged(int)));

    languageLayout = new QHBoxLayout;
    languageLayout->addWidget(languageLabel);
    languageLayout->addWidget(languageCombo);

    setupLayout = new QVBoxLayout;
    setupLayout->addLayout(languageLayout);
    languageGroup->setLayout(setupLayout);

    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(languageGroup);
    mainLayout->addStretch(1);
    setLayout(mainLayout);
}

void SetLangPage::langChanged(int index)
{
    SNS_lng_set = new QSettings("/boot/home/config/settings/Synopson_config", QSettings::IniFormat);
    SNS_lng_set->setValue("Language/SNSlocale", index); // set
    SNS_lng_set->sync(); // save
    QMessageBox::information(this, tr("Change of language."), tr("The interface language of Synopson was changed.<br>"
                                                                "These changes will become effective in case of next run of application."));
}

OtherPage::OtherPage(QWidget *parent) : QWidget(parent)
{
    QGroupBox *otherGroup = new QGroupBox(tr("Something else..."));
    QImage img(":/Images/Set.png");
    QLabel *imgLabel = new QLabel;
    imgLabel->setPixmap(QPixmap::fromImage(img));
    QLabel *otherLabel = new QLabel(tr("Something else..."));
    QVBoxLayout *vLayout = new QVBoxLayout;
    vLayout->addWidget(imgLabel);
    vLayout->addWidget(otherLabel);
    otherGroup->setLayout(vLayout);
    QVBoxLayout *mainLayout = new QVBoxLayout;
    mainLayout->addWidget(otherGroup);
    mainLayout->addStretch(1);
    setLayout(mainLayout);
}
