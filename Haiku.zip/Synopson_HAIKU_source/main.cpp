/****************************************************************
 *   file manager                                               *
 *   2011 by Thomas F�hringer <thomasfuhringer@gmail.com>       *
 *   provided under the terms of the GPL                        *
 ****************************************************************/

#include "MainWindow.h"

int main(int argc, char *argv[])
{
    int SNS_Locale = 0;
    QTranslator setLanguage;
    QTranslator qtTranslator;

    QApplication app(argc, argv);
    app.setApplicationName("Synopson");

    if (QFile::exists("/boot/home/config/settings/Synopson_config")) {
        QSettings *Lng_active = new QSettings("/boot/home/config/settings/Synopson_config", QSettings::IniFormat);
        SNS_Locale = Lng_active->value("Language/SNSlocale", 0).toInt();
            switch (SNS_Locale) {
                case 0:
                    break;
                case 1:
//                    qtTranslator.load("qt_ru", qApp->applicationDirPath()+"/Translation/");
//                    app.installTranslator(&qtTranslator);
                    setLanguage.load("Synopson_ru", qApp->applicationDirPath()+"/Translation/");
                    app.installTranslator(&setLanguage);
                    break;
                case 2:
                    setLanguage.load("Synopson_ua", qApp->applicationDirPath()+"/Translation/");
                    app.installTranslator(&setLanguage);
                    break;
                case 3:
                    setLanguage.load("Synopson_de", qApp->applicationDirPath()+"/Translation/");
                    app.installTranslator(&setLanguage);
                    break;
            }
    }

    MainWindow mainWindow;
    mainWindow.show();

    return app.exec();
}
