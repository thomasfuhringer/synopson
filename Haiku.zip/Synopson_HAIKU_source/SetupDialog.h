#ifndef SETUPDIALOG_H
#define SETUPDIALOG_H

#include <QtInc.h>

QT_BEGIN_NAMESPACE
class QListWidget;
class QListWidgetItem;
class QStackedWidget;

class SetupDialog : public QDialog
{
    Q_OBJECT

public:
    SetupDialog();

public slots:
    void changePage(QListWidgetItem *current, QListWidgetItem *previous);

private:
    void createIcons();

    QListWidget *contentsWidget;
    QStackedWidget *pagesWidget;
    QPushButton *closeButton;
    QHBoxLayout *horizontalLayout;
    QHBoxLayout *buttonsLayout;
    QVBoxLayout *mainLayout;
    QListWidgetItem *SetLangButton;
    QListWidgetItem *otherButton;
};

class SetLangPage : public QWidget // Setup language page
{
    Q_OBJECT

public:
    SetLangPage(QWidget *parent = 0);

    QSettings *SNS_lng_set;

public slots:
    void langChanged(int);

private:
   QLabel *languageLabel;
   QGroupBox *languageGroup;
   QComboBox *languageCombo;
   QHBoxLayout *languageLayout;
   QVBoxLayout *mainLayout;
   QVBoxLayout *setupLayout;
};

class OtherPage : public QWidget
{
public:
    OtherPage(QWidget *parent = 0);
};

QT_END_NAMESPACE

#endif // SETUPDIALOG_H
